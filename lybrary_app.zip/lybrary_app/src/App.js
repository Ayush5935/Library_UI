import './App.css';
// import { Sidebar } from './components/Sidebar';
import { AddNewBook } from './components/Book/AddNewBook';
import { RemoveBook } from './components/Book/RemoveBook';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { About } from './components/About';
import { Register } from './components/Auth/Register';
import { Login } from './components/Auth/Login';
import { AddNewLibrary } from './components/Library/LibraryCreate';
import Books from './components/Book/Books';
import BookRequest from './components/Book/MyRequests';
import MyRequests from './components/Book/MyRequests';
import AdminRequests from './components/Admin/AdminRequests';
import { UpdateBook } from './components/Admin/UpdateBook';
import { Issues } from './components/Admin/Issues';
import { UpdateByIsbn } from './components/Admin/UpdateByIsbn';
import { Sidebar } from './components/Sidebar/Sidebar';
import { SearchBook } from './components/Book/SearchBooks';
import { Book } from './components/Book/Book';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <SearchBook />
        <Sidebar />
        <Routes>

          <Route path='/' element={<About />} />
          <Route path='/auth/register' element={<Register />} />
          <Route path='/auth/login' element={<Login />} />
          <Route path='/owner/add-new-library' element={<AddNewLibrary />} />
          <Route path='/admin/add-new-book' element={<AddNewBook />} />
          <Route path='/api/books' element={<Books />} />
          <Route path='/api/books/request' element={<BookRequest />} />
          <Route path='/remove-book' element={<RemoveBook />} />
          <Route path='/api/my-requests' element={<MyRequests />} />
          <Route path='/admin/issue-book' element={<AdminRequests />} />
          <Route path='/admin/book-update/:isbn' element={<UpdateBook />} />
          <Route path='/admin/book-update' element={<UpdateByIsbn />} />
          <Route path='/admin/issues' element={<Issues />} />
          <Route path='/api/book/:isbn' element={<Book />} />
          {/* <AddNewBook />
        <RemoveBook /> */}
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
