import React, { useState, useEffect } from 'react';
import axios from '../../utils/axios';
import { Sidebar } from '../Sidebar/Sidebar';
const MyRequests = () => {
    const [requests, setRequests] = useState([]); const borrow = {
        "request_type": "borrow",
    };

    useEffect(() => {
        const fetchRequests = async () => {
            try {
                const response = await axios.get('/api/requests');
                setRequests(response.data?.My_requests);
                console.log(response?.data?.My_requests)
            } catch (error) {
                console.error('Error fetching books:', error);
            }
        };
        fetchRequests();
    }, []);
    const handleReturn = async (bookISBN) => {
        try {
            const response = await axios.post('http://localhost:8080/api/request/' + bookISBN, borrow);
            console.log("qwertyuio", response);
            // window.location.reload()
        } catch (error) {
            console.error('Error fetching books:', error);
        }
    };

    return (
        <>
            <div className="container-addbook">
                <h2>My Requests</h2>
                <hr />
                <table className="table-class">
                    <thead>
                        <tr>
                            <th>ISBN</th>
                            <th>Request Type</th>
                        </tr>
                    </thead>
                    <tbody>
                        {requests?.map((item) => (
                            <tr key={item.request_id}>
                                <td>{item.book_isbn}</td>
                                <td>{item.request_type}</td>
                                {item.request_type === "borrow" ?
                                    <td><button onClick={() => handleReturn(item.book_isbn)}>Return</button></td>
                                    : <></>}
                            </tr>

                        ))}
                    </tbody>
                </table>
            </div>
        </>
    );
};
export default MyRequests;