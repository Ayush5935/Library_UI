import { useEffect, useState } from "react";
import axios from '../../utils/axios';
import '../Book/addnewbook.css';
import { useParams } from "react-router-dom";
export function Book() {

    const { isbn } = useParams()

    const [updateBook, setUpdateBook] = useState({});

    console.log("12345678", isbn)

    useEffect(() => {
        const fetchBook = async () => {
            try {
                const response = await axios.get('http://localhost:8080/api/book/' + isbn)
                setUpdateBook(response.data);
                console.log(response.data);
            } catch (error) {
                console.error('Error fetching books:', error);

            }
        };
        fetchBook();

    }, [isbn])

    return (
        <>
            <div className="container-addbook">
                <h2>Book details</h2>
                <hr />
            </div>
            <div>
                <form>
                    <label for="ISBN">ISBN</label>
                    <input type="text" name="ISBN" placeholder="ISBN" value={updateBook.isbn} onChange={(e) => setUpdateBook({ ...updateBook, isbn: e.target.value })} disabled />
                    <label for="Title">Title</label>
                    <input type="text" name="Title" placeholder="Title" value={updateBook.title} onChange={(e) => setUpdateBook({ ...updateBook, title: e.target.value })} disabled />
                    <br />
                    <label for="Authors">Authors</label>
                    <input type="text" name="Authors" placeholder="Authors" value={updateBook.authors} onChange={(e) => setUpdateBook({ ...updateBook, authors: e.target.value })} disabled />
                    <label for="Publisher">Publisher</label>
                    <input type="text" name="Publisher" placeholder="Publisher" value={updateBook.publisher} onChange={(e) => setUpdateBook({ ...updateBook, publisher: e.target.value })} disabled />
                    <br />
                    <label for="Version">Version</label>
                    <input type="text" name="Version" placeholder="Version" value={updateBook.version} onChange={(e) => setUpdateBook({ ...updateBook, version: e.target.value })} disabled />
                    <label for="TotalCopies">TotalCopies</label>
                    <input type="number" name="TotalCopies" placeholder="Total Copies" value={updateBook.total_copies} onChange={(e) => setUpdateBook({ ...updateBook, total_copies: e.target.value })} disabled />
                    <br />
                    <label for="AvailableCopies">AvailableCopies</label>
                    <input type="number" name="AvailableCopies" placeholder="Available Copies" value={updateBook.available_copies} onChange={(e) => setUpdateBook({ ...updateBook, available_copies: e.target.value })} disabled />
                    {/* <button type="submit">Update Book</button> */}
                </form>
            </div>
        </>)
}