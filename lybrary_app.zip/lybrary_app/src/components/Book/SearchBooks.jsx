import { useEffect, useState } from "react";
import axios from '../../utils/axios';
import '../Book/searchBooks.css'
import { useNavigate } from "react-router-dom";

export function SearchBook() {

    const navigate = useNavigate()

    const [query, setQuery] = useState("");
    const [searchResults, setSearchResults] = useState([]);
    const [isOpen, setIsOpen] = useState(false)


    const handleInputChange = async (e) => {
        setQuery(e.target.value)
    }

    const handleSearch = async (e) => {
        try {
            const response = await axios.get(`http://localhost:8080/api/books/search?query=${query}`)
            // const data = await response.json();
            setSearchResults(response.data);
            setIsOpen(true);
            console.log("_+___", searchResults);
        } catch (error) {
            setSearchResults([])
            console.error('Error searching for books:', error);
        }
    }

    const handleClickOutside = (e) => {
        if (!document.getElementById('searchResults').contains(e.target)) {
            setQuery(""); // Clicked outside, hide results
        }
    };

    useEffect(() => {
        handleSearch(query);
        document.addEventListener('click', handleClickOutside);
        return () => {
            document.removeEventListener('click', handleClickOutside);
        };
    })


    return (
        <>
            <header className="header-container">
                <from>
                    <input id="searchResults" type="text" value={query} onChange={(e) => handleInputChange(e)} placeholder="Search books" ></input>
                    <button type="submit" onClick={handleSearch}>Search</button>
                </from>
            </header>
            {console.log("-----", searchResults)}
            {isOpen && searchResults.length > 0 &&
                <div className="search-res">
                    <ul>
                        {searchResults.map(book => (
                            <li key={book.isbn}>
                                Title: {book.title}, Author: {book.authors}
                                <button onClick={() => {
                                    navigate(`/api/book/${book?.isbn}`)

                                        ("")
                                }}>View Book</button>
                            </li>
                        ))}
                    </ul>
                </div>
            }
        </>
    )
}