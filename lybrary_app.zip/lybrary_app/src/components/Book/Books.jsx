import React, { useState, useEffect } from 'react';
import '../Book/books.css';
import axios from '../../utils/axios';
import { useNavigate } from 'react-router-dom';

const Books = () => {
    const navigate = useNavigate();
    // const [isbn, setIsbn] = useState("");

    const [requests, setRequests] = useState([]);
    // const [issues, setIssues] = useState([]);
    const [books, setBooks] = useState([]);
    const borrow = {
        "request_type": "borrow",
    };
    const role = localStorage.getItem("role")

    useEffect(() => {
        const fetchBooks = async () => {
            try {
                const response = await axios.get('/api/library/books');
                setBooks(response.data?.Books);

            } catch (error) {
                console.error('Error fetching books:', error);
            }
        };

        // const fetchRequests = async () => {
        //     try {
        //         const response = await axios.get('/api/issues');
        //         setIssues(response.data?.my_issues);
        //         console.log(response?.data?.my_issues);
        //     } catch (error) {
        //         console.error('Error fetching books:', error);
        //     }
        // };

        // const fetchIssues = async () => {
        //     try {
        //         const response = await axios.get('/api/requests');
        //         setRequests(response.data?.My_requests);
        //         console.log(response?.data?.My_requests)
        //     } catch (error) {
        //         console.error('Error fetching books:', error);
        //     }
        // };

        // fetchRequests();
        fetchBooks();
        // fetchIssues()
    }, []);

    const handleRequest = async (bookISBN) => {
        try {
            const response = await axios.post('http://localhost:8080/api/request/' + bookISBN, borrow);
            console.log("qwertyuio", response);
            navigate('/api/my-requests')
        } catch (error) {
            console.error('Error fetching books:', error);
        }
    };



    return (
        <>
            <div className="container-addbook">
                <h2>All Books</h2>
                <hr />
                <ul className="book-container">
                    {books?.map((item, index) => (
                        <li key={index}>
                            {item.isbn} {item.title} By {item.authors}
                            {/* {requests?.map((el) => (
                                <li key={el.request_id}>
                                    {el.request_type}
                                </li>
                            ))} */}
                            {role === "admin" ?
                                <button type='button'
                                    onClick={() => {
                                        navigate(`/admin/book-update/${item?.isbn}`)
                                    }}>Update</button>
                                :
                                <button type='submit' onClick={() => handleRequest(item.isbn)}>Request</button>
                            }
                            {/* {el.book_isbn === item.isbn && el.request_type === "borrow" ?

                                <button type='submit' onClick={() => handleBorrow(item.isbn)}>return</button>
                                :
                                <button type='submit' onClick={() => handleBorrow(item.isbn)}>borrow</button>
                            }
                            {console.log(requests)} */}
                            <hr />
                        </li>
                    ))}
                </ul>
            </div>
        </>
    );
};

export default Books;