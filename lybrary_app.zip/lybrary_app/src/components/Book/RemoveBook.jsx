import { useEffect, useState } from "react";
import { Sidebar } from "../Sidebar/Sidebar";
// import axios from "axios";
import axios from '../../utils/axios';
import './removebook.css'

export function RemoveBook() {
    const [bookId, setBookId] = useState("");
    const [updateBook, setUpdateBook] = useState({})

    useEffect(() => {
        const fetchBook = async () => {
            try {
                const response = await axios.get('http://localhost:8080/api/book/' + bookId)
                setUpdateBook(response.data);
                console.log(response.data);
            } catch (error) {
                console.error('Error fetching books:', error);
            }
        };
        fetchBook();

    }, [bookId])

    const handleDelete = async (e) => {
        e.preventDefault();
        try {
            // window.alert("The book will be deleted?")
            if (window.confirm('The book will be deleted.')) {
                const res = await axios.delete(`http://localhost:8080/admin/library/book/${bookId}`);
                console.log(res);
                window.location.reload()
            }
        } catch (err) {
            console.error(err);
        }
    }
    return (<>
        <div className="container-addbook">
            <h2>Remove a booK</h2>
            <hr />
        </div>
        <div>
            <form>
                <label>Enter Book ISBN:</label>
                <input type="text" placeholder="Book Id"
                    value={bookId}
                    onChange={(e) => {
                        setBookId(e.target.value)
                    }}
                    required />
                {/* <button onClick={handleDelete}>Remove Book</button> */}
            </form>
        </div>
        <div>
            <form onSubmit={handleDelete}>
                <input type="text" name="ISBN" placeholder="ISBN" value={updateBook.isbn} onChange={(e) => setUpdateBook({ ...updateBook, isbn: e.target.value })} disabled />
                <input type="text" name="Title" placeholder="Title" value={updateBook.title} onChange={(e) => setUpdateBook({ ...updateBook, title: e.target.value })} />
                <input type="text" name="Authors" placeholder="Authors" value={updateBook.authors} onChange={(e) => setUpdateBook({ ...updateBook, authors: e.target.value })} />
                <input type="text" name="Publisher" placeholder="Publisher" value={updateBook.publisher} onChange={(e) => setUpdateBook({ ...updateBook, publisher: e.target.value })} />
                <input type="text" name="Version" placeholder="Version" value={updateBook.version} onChange={(e) => setUpdateBook({ ...updateBook, version: e.target.value })} />
                <input type="number" name="TotalCopies" placeholder="Total Copies" value={updateBook.total_copies} onChange={(e) => setUpdateBook({ ...updateBook, total_copies: e.target.value })} />
                <input type="number" name="AvailableCopies" placeholder="Available Copies" value={updateBook.available_copies} onChange={(e) => setUpdateBook({ ...updateBook, available_copies: e.target.value })} />
                <button type="submit">Remove Book</button>
            </form>
        </div>
    </>)
}