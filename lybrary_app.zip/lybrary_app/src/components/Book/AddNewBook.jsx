import { useState } from "react";
import axios from "axios";

import './addnewbook.css';
import { Sidebar } from "../Sidebar/Sidebar";
export function AddNewBook() {
    const [bookData, setBookData] = useState({
        "isbn": "",
        "title": "",
        "authors": "",
        "publisher": "",
        "version": "",
        "total_copies": "",
        "available_copies": ""
    });

    // function handleChange(e) {
    //     const { name, value } = e.target;
    //     setBookData({ ...bookData, [name]: value })
    // }

    const handleSubmit = async (e) => {

        const token = localStorage.getItem('token')
        console.log("-werty---", token)
        console.log("----", bookData)
        e.preventDefault();
        try {
            const bookWithNumber = {
                ...bookData,
                available_copies: +bookData.available_copies,
                total_copies: +bookData.total_copies,
            };
            const res = await axios.post('http://localhost:8080/admin/library/book', bookWithNumber, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                }
            });
            console.log("res", res.data)
        } catch (err) {
            console.error("Error:", err)
        }
    }
    return (
        <>
            <div className="container-addbook">
                <h2>Add a new booK</h2>
                <hr />
            </div>
            <div>
                <form onSubmit={handleSubmit}>
                    <input type="text" name="ISBN" placeholder="ISBN" value={bookData.isbn} onChange={(e) => setBookData({ ...bookData, isbn: e.target.value })} required />
                    <input type="text" name="Title" placeholder="Title" value={bookData.title} onChange={(e) => setBookData({ ...bookData, title: e.target.value })} required />
                    <input type="text" name="Authors" placeholder="Authors" value={bookData.authors} onChange={(e) => setBookData({ ...bookData, authors: e.target.value })} required />
                    <input type="text" name="Publisher" placeholder="Publisher" value={bookData.publisher} onChange={(e) => setBookData({ ...bookData, publisher: e.target.value })} required />
                    <input type="text" name="Version" placeholder="Version" value={bookData.version} onChange={(e) => setBookData({ ...bookData, version: e.target.value })} required />
                    <input type="number" name="TotalCopies" placeholder="Total Copies" value={bookData.total_copies} onChange={(e) => setBookData({ ...bookData, total_copies: e.target.value })} required />
                    <input type="number" name="AvailableCopies" placeholder="Available Copies" value={bookData.available_copies} onChange={(e) => setBookData({ ...bookData, available_copies: e.target.value })} required />
                    <button type="submit">Add Book</button>
                </form>
            </div>
        </>)
}