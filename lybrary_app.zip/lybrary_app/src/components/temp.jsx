import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Search = () => {
    const [query, setQuery] = useState('');
    const [results, setResults] = useState([]);
    const [showResults, setShowResults] = useState(false);

    const handleSearch = async () => {
        try {
            const response = await axios.get(`http://localhost:8080/api/search/books?query=${query}`);
            setResults(response.data);
            setShowResults(true); // Show results after search
        } catch (error) {
            console.error('Error searching books:', error);
        }
    };

    const handleClickOutside = (e) => {
        if (!document.getElementById('searchResults').contains(e.target)) {
            setShowResults(false); // Clicked outside, hide results
        }
    };

    useEffect(() => {
        document.addEventListener('click', handleClickOutside);
        return () => {
            document.removeEventListener('click', handleClickOutside);
        };
    }, []);

    return (
        <div>
            <h1>Search Books</h1>
            <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Enter your search query"
            />
            <button onClick={handleSearch}>Search</button>

            {showResults && results.length > 0 && (
                <div id="searchResults">
                    <h2>Search Results:</h2>
                    <ul>
                        {results.map(book => (
                            <li key={book.isbn}>
                                Title: {book.title}, Author: {book.author}
                            </li>
                        ))}
                    </ul>
                </div>
            )}

            {showResults && results.length === 0 && (
                <div id="noResults">
                    <p>No results found.</p>
                </div>
            )}
        </div>
    );
};

export default Search;