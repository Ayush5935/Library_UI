import { useEffect, useState } from "react";
import { Sidebar } from "../Sidebar/Sidebar";
// import axios from "axios";
import axios from '../../utils/axios';
import '../Book/removebook.css'

export function UpdateByIsbn() {
    const [bookId, setBookId] = useState("");
    const [updateBook, setUpdateBook] = useState({})

    useEffect(() => {
        const fetchBook = async () => {
            try {
                const response = await axios.get('http://localhost:8080/api/book/' + bookId)
                setUpdateBook(response.data);
                console.log(response.data);
            } catch (error) {
                console.log('Book is not available.', bookId);
            }
        };
        fetchBook(bookId);

    }, [bookId])

    const handleUpdateById = async (e) => {

        const token = localStorage.getItem('token')
        console.log("-werty---", token)
        console.log("----", updateBook)
        e.preventDefault();
        try {
            const bookWithNumber = {
                ...updateBook,
                available_copies: +updateBook.available_copies,
                total_copies: +updateBook.total_copies,
            };
            const res = await axios.put('http://localhost:8080/admin/library/book/' + bookId, bookWithNumber, {
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                }
            });
            console.log("res", res.data)
        } catch (err) {
            console.error("Error:", err)
        }
    }

    return (<>
        <div className="container-addbook">
            <h2>Update booK</h2>
            <hr />
        </div>
        <div>
            <form>
                <input type="text" placeholder="Book Id"
                    value={bookId}
                    onChange={(e) => {
                        setBookId(e.target.value)
                    }}
                    required />
                {/* <button onClick={handleUpdateById}>Find Book</button> */}
            </form>
        </div>
        <div>
            <form onSubmit={handleUpdateById}>
                <input type="text" name="ISBN" placeholder="ISBN" value={updateBook.isbn} onChange={(e) => setUpdateBook({ ...updateBook, isbn: e.target.value })} disabled />
                <input type="text" name="Title" placeholder="Title" value={updateBook.title} onChange={(e) => setUpdateBook({ ...updateBook, title: e.target.value })} />
                <input type="text" name="Authors" placeholder="Authors" value={updateBook.authors} onChange={(e) => setUpdateBook({ ...updateBook, authors: e.target.value })} />
                <input type="text" name="Publisher" placeholder="Publisher" value={updateBook.publisher} onChange={(e) => setUpdateBook({ ...updateBook, publisher: e.target.value })} />
                <input type="text" name="Version" placeholder="Version" value={updateBook.version} onChange={(e) => setUpdateBook({ ...updateBook, version: e.target.value })} />
                <input type="number" name="TotalCopies" placeholder="Total Copies" value={updateBook.total_copies} onChange={(e) => setUpdateBook({ ...updateBook, total_copies: e.target.value })} />
                <input type="number" name="AvailableCopies" placeholder="Available Copies" value={updateBook.available_copies} onChange={(e) => setUpdateBook({ ...updateBook, available_copies: e.target.value })} />
                <button type="submit">Update Book</button>
            </form>
        </div>

    </>)
}