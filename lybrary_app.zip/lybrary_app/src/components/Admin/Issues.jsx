import { useEffect, useState } from "react";
import axios from '../../utils/axios';
import '../Book/addnewbook.css';
export function Issues() {

    const [issues, setIssues] = useState([])

    useEffect(() => {
        const fetchIssues = async () => {
            try {
                const response = await axios.get('http://localhost:8080/admin/library/book/issues')
                setIssues(response?.data?.all_issues);
                console.log(response?.data?.all_issues);
            } catch (error) {
                console.error('Error fetching books:', error);
            }
        };
        fetchIssues();

    }, [])

    const handleReturnIssue = (issue_id) => {
        axios.put(`http://localhost:8080/admin/library/book/issue/${issue_id}`)
            .then(response => {
                // Handle success
                console.log(`Request ${issue_id} returned.`);
                window.location.reload()
            })
            .catch(error => {
                console.error(error);
            });
    };

    return (
        <>
            <div>
                <h2>All Issues</h2>
                <hr />
                {/* <ul className="book-container">
                    {issues?.map((item) => (
                        <li key={item.issue_id}>
                            {item.isbn} {item.issue_approver_id} {item.issue_date} {item.issue_status} {item.reader_id} {item.return_approver_id} {item.return_date}

                            <hr />
                        </li>
                    ))}
                </ul> */}
                <div className="container-issue">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>ISBN</th>
                                <th>Issue Approver ID</th>
                                <th>Issue Status</th>
                                <th>Issue Date</th>
                                <th>Exp Return Date</th>
                                <th>Reader ID</th>
                                <th>Return Approver ID</th>
                                <th>Return Date</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>

                            {issues?.map((item) => (
                                <tr key={item.issue_id}>
                                    <td>{item.issue_id}</td>
                                    <td>{item.isbn}</td>
                                    <td>{item.issue_approver_id}</td>
                                    <td>{item.issue_status}</td>
                                    <td>{item.issue_date}</td>
                                    <td>{item.expected_return_date}</td>
                                    <td>{item.reader_id}</td>
                                    <td>{item.return_approver_id}</td>
                                    <td>{item.return_date}</td>
                                    {item.issue_status === "returned" ?
                                        <span></span>
                                        :
                                        <td><button onClick={() => handleReturnIssue(item.issue_id)}>Return</button></td>
                                    }
                                    {console.log(item.issue_status === "returned")}
                                </tr>

                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

        </>)
}