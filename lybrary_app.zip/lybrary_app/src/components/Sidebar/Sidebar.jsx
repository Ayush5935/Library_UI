import { Link } from 'react-router-dom';
import '../../components/Sidebar/sidebar.css';
export const Sidebar = () => {
    const role = localStorage.getItem("role")
    const username = localStorage.getItem("username")
    const token = localStorage.getItem("token")

    const logout = () => {
        // window.alert("Are you sure to logout?")
        if (window.confirm('Are you sure to logout?')) {
            localStorage.clear()
            window.location.href = "/"
        }
    }

    // setRole = localStorage.getItem("role")
    // setUsername = localStorage.getItem("username")
    return (
        <>
            <div className="side">
                <div className="side-container">
                    <h1>Hello {username}</h1>
                    <hr />
                    <div className="side-container-list">
                        <ul>
                            {!token ? <>
                                <Link to="/auth/register"><li>Register</li></Link>
                                <Link to="/auth/login"><li>Login</li></Link>
                            </>
                                :
                                <li onClick={logout}>Logout</li>
                            }
                            {role === "owner" ?
                                <>
                                    <Link to="/owner/add-new-library"><li>Add Library</li></Link>
                                    <Link to="/api/books"><li>All Books</li></Link>
                                </>
                                : role === "admin" ?
                                    <>
                                        <Link className="hello" to="/api/books"><li>All Books</li></Link>
                                        <Link to="/admin/add-new-book"><li>Add new booK</li></Link>
                                        <Link to="/admin/book-update"><li>Update booK</li></Link>
                                        <Link to="/admin/issue-book"><li>All Requests</li></Link>
                                        <Link to="/admin/issues"><li>Issue requestS</li></Link>
                                        <Link to="/remove-book"><li>Remove booK</li></Link>
                                    </>
                                    : role === "reader" ?
                                        <>
                                            <Link to="/api/books"><li>All Books</li></Link>
                                            <Link to="/api/my-requests"><li>My Requests</li></Link>

                                            {/* <Link to="/generate-request"><li>Generate Request</li></Link> */}
                                        </> : <></>
                            }
                            {/* <Link to="/api/books"><li>All Books</li></Link> */}


                        </ul>
                    </div>
                </div>
            </div >
        </>
    )
}