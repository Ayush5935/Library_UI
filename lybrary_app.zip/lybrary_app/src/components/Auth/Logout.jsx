import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'
import axios from 'axios';
import '../Book/addnewbook.css';
import { Sidebar } from "../Sidebar/Sidebar";

export function Logout() {

    const logout = () => {
        // window.alert("Are you sure to logout?")
        localStorage.clear()
    }
    return (
        <>
            <button onClick={() => { if (window.confirm('Delete the item?')) { logout } }}>Logout</button>
        </>)
}