import { useEffect, useState } from "react";
import axios from "axios";
import '../Book/addnewbook.css';
import { Sidebar } from '../Sidebar/Sidebar';
import { useNavigate } from "react-router-dom";
export function Register() {

    const navigate = useNavigate();
    const [user, setUser] = useState({
        "name": "",
        "email": "",
        "password": "",
        "contact_number": "",
        "role": "",
        "valid_key": "",
        "lib_id": null,
    });
    const num = Number('2020');
    function handleChange(e) {
        const { name, value } = e.target;
        setUser({ ...user, [name]: value })
    }

    const handleSubmit = async (e) => {
        console.log(user.lib_id);
        e.preventDefault();
        try {
            const userWithNumberLibId = {
                ...user,
                lib_id: +user.lib_id,
            };
            const res = await axios.post('http://localhost:8080/auth/user/register', userWithNumberLibId, {
                headers: {
                    'Content-Type': 'application/json',
                }
            });
            console.log("res", res.data)

            navigate('/auth/login')

        } catch (err) {
            console.log(num);
            console.error("Error:", err)
        }
    }

    useEffect((e) => {
        setUser(user)
    })

    return (
        <>
            <div className="container-addbook">
                <h2>Registration</h2>
                <hr />
            </div>
            <div>
                <form>
                    <input type="text" name="name" placeholder="Name" value={user.name} onChange={(e) => handleChange(e)} required />
                    <input type="email" name="email" placeholder="Email" value={user.email} onChange={(e) => handleChange(e)} required />
                    <input type="text" name="contact_number" placeholder="Contact Number" value={user.contact_number} onChange={(e) => setUser({ ...user, contact_number: e.target.value })} required />
                    <input type="password" name="password" placeholder="Password" value={user.password} onChange={(e) => setUser({ ...user, password: e.target.value })} required />
                    <input type="text" name="role" placeholder="Role" value={user.role} onChange={(e) => handleChange(e)} required />
                    {user.role === "owner" || user.role === "admin" ?
                        <input type="password" name="valid_key" placeholder="Valid key" value={user.valid_key} onChange={(e) => setUser({ ...user, valid_key: e.target.value })} required />
                        : <span></span>}
                    <input type="number" name="lib_id" placeholder="Library Id" value={user.lib_id || ""} onChange={(e) => setUser({ ...user, lib_id: e.target.value })} />
                    <button type="button" onClick={handleSubmit} placeholder="Submit" id="add-button">Submit</button> </form>
            </div>
        </>
    )
}