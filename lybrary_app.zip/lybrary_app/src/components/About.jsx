import "./about.css"

export function About() {
    return (
        <>
            <div className="container-addbook">
                <h1>Welcome to Library Management System</h1>
                <hr />
                <div className="about">
                    <ul>
                        <li>Owner:</li>
                        <ul>
                            <li>Can create libraries.</li>
                            <li>Can see libraries.</li>
                            <li>can delete libraries.</li>
                            <li>Can see books.</li>
                        </ul>
                        <li>Admin:</li>
                        <ul>
                            <li>Can add book in which specific library assigned.</li>
                            <li>Can see books.</li>
                            <li>Can Update books.</li>
                            <li>can delete books.</li>
                            <li>can issue books: borrow/return.</li>
                        </ul>
                        <li>Reader:</li>
                        <ul>
                            <li>Can see books.</li>
                            <li>Can raise request books: borrow/return.</li>
                        </ul>
                    </ul></div>
            </div>
        </>
    )
}